﻿namespace Blog.Core.Model.Systems.DataBase;

/// <summary>
/// 数据库读取类型
/// </summary>
public enum DataBaseReadType
{
    Db,
    Entity
}