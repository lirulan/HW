﻿namespace Blog.Core.Model.Systems.DataBase;

public class EditTableInput
{
    public string ConfigId { get; set; }

    public string TableName { get; set; }

    public string Description { get; set; }
}