﻿using System;

namespace Blog.Core.Model
{
    public enum HttpEnum
    {
        Common,
        LocalHost
    }
}
