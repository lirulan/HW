﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Core.Model.ViewModels
{
    public class WeChatPushTextContentDto
    {
        /// <summary>
        /// 文字消息
        /// </summary>
        public string text { get; set; }
    }
}
