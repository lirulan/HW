﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Core.Model.ViewModels
{
    /// <summary>
    /// 微信二维码预装具体消息
    /// </summary>
    public class WeChatQRActionInfoDto
    {
        public string scene_str { get; set; } 
    }
}
