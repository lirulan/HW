﻿namespace Blog.Core.Model.ViewModels
{
    public  class ModuleViewModels
    {
    }
}
