﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blog.Core.Model.ViewModels
{
    /// <summary>
    /// 微信二维码预装发送信息dto
    /// </summary>
    public class WeChatQRActionDto
    {
        public WeChatQRActionInfoDto scene { get; set; }
    }
}
