﻿namespace Blog.Core.Common.Const;

public class SqlSugarConst
{
    /// <summary>
    /// 默认Log数据库标识
    /// </summary>
    public const string LogConfigId = "Log";
}