BlogCore官方文档仓库地址已经迁移到：   
https://gitee.com/laozhangIsPhi/Blog.Core.E-Book  