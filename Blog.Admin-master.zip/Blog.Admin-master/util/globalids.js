global.antRouter = ''//全局的路由
// 使用id4更改这里2
global.IS_IDS4 = true // 默认false，表示使用JWT模式，如果true，表示使用ids4