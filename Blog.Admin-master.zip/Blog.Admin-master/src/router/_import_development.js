//开发环境导入组件
module.exports = file => require('@/views' + file + '.vue').default
