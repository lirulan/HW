<template>
    <p class="page-container">403 No permissions</p>
</template>

<style >
    .page-container {
        font-size: 25px;
        text-align: center;
        color: rgb(192, 204, 218);
    }
</style>
