<template >
    <div style="padding:30px;">
        <el-alert :closable="false" title="menu - 1 - 1 - 2" type="error" />
    </div>
</template>

<script>
    export default {
        name: "Menu111"
    }
</script>

<style scoped>

</style>
