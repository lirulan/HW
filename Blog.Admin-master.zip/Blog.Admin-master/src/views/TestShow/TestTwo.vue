<template>
    <div>我是测试的第二个页面.</div>

</template>

<script>
    export default {
        name: "TestTwo"
    }
</script>

<style scoped>

</style>
