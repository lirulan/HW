
## 更新日志

###  2020-07-15  
> 重要内容更新：权限分配页中，按钮展示优化，去掉了 `_{id}` 非必要部分.  [4f74b43](https://github.com/anjoy8/Blog.Admin/commit/4f74b43ba0cfa59166391cdfe01b2d4e8492fce5)  
> 注意要保证后端代码同步更新。


###  2020-07-13  
> 重要内容更新：左侧导航条支持外链（必须满足正确的 `URL` 要求，比如带 `Http` 协议） [7d822c9](https://github.com/anjoy8/Blog.Admin/commit/7d822c987c39ec7b00deb1c5b1c54c06b023f928)


###  2020-05-01  
> 重要内容更新：集成按钮级别权限


###  2020-04-30  
> 新增：主分支，通过global.js配置，一键切换JWT和Ids4认证授权模式    

