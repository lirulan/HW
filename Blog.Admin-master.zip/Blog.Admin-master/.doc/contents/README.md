---
home: true
heroImage: /bahomelogo.png
actionText: 快速上手 →
actionLink: /guide/
features:
- title: 详尽的文档
  details: 通过详细的文章和视频讲解，将知识点各个击破，掌握 VUE 不再难
- title: 强大的社区
  details: 通过 QQ 群，和千位大佬一起切磋交流。
- title: 丰富的内容
  details: 框架涵盖 VUE 开发中常见的基本知识点，不仅适合初学者入门，同时也适用于企业级别的开发。
footer: MIT Licensed | Copyright © 2018-2020-老张的哲学
---